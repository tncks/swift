class SomeClass {}

var someAnyObject: AnyObject = SomeClass()

//someAnyObject = 123.12

