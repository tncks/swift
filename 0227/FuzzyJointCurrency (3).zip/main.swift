struct BasicInformation
{
  var name: String
  var age: Int
}

var yagomInfo: BasicInformation = BasicInformation(name: "yagom", age: 99)
yagomInfo.age = 100
yagomInfo.name = "Bear"

let hanaInfo: BasicInformation = BasicInformation(name: "hana", age: 99)
//hanaInfo.age = 100

