//var numberForName : Dictionary = Dictionary()

// var numberForName: [String: Int] = [String: Int]()

//var numberForName: [String: Int] = [:]

var numberForName: [String:Int] = ["yagom":100, "chulsoo":200, "jenny":340]

print(numberForName.isEmpty)
print(numberForName.count)