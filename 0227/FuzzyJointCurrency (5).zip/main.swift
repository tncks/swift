protocol Talkable
{
  var topic : String { get set}
  func talk(to: Person)
  init(name: String, topic: String)
}

struct Person: Talkable
{
  var topic: String
  var name: String

  
  func talk(to: Person)
  {
    print("\(topic)에 대해 \(to.name)에게 이야기합니다.")
  }
  
  
  init(name: String, topic: String)
  {
    self.name = name
    self.topic = topic
  }
  
}

let yagom: Person = Person(name: "야곰", topic : "스위프트")
let hana : Person = Person(name: "하나", topic: "코딩")



