var names: Array = ["yagom",  "chulsoo", "younghee", "yagom"]

//var names: [String] =  ["yagom",  "chulsoo", "younghee", "yagom"]

var emptyArray : [String] = [String]()

//var emptyArray : [String] = Array()

//var emptyArray : [String] = []

print(emptyArray.isEmpty)
print(names.count)
