class Person
{
  var height: Float = 0.0
  var weight: Float = 0.0
  deinit
  {
    print("Person 클래스의 인스턴스가 소멸됩니다.")
  }
}

var yagom: Person = Person()
yagom.height = 123.4
yagom.weight = 123.4

let hana: Person = Person()
hana.height = 123.4
hana.weight = 123.4

print(yagom.height)
print(hana.weight)