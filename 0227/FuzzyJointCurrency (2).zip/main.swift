//var numberForName : Dictionary = Dictionary()

// var numberForName: [String: Int] = [String: Int]()

//var numberForName: [String: Int] = [:]

var numberForName: [String:Int] = ["yagom":100, "chulsoo":200, "jenny":340]

print(numberForName.isEmpty)
print(numberForName.count)

print(numberForName["chulsoo"])
print(numberForName["minji"])

numberForName["chulsoo"] = 150
print(numberForName["chulsoo"])

numberForName["max"] = 999
print(numberForName["max"])

print(numberForName.removeValue(forkey: "yagom"))
print(numberForName.removeValue(forkey: "yagom"))