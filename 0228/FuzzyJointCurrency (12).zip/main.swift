var integers = [1,2,3]

while integers.count > 1 {
  integers.removeLast()
}