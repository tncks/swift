let setA: Set = [1,2,3,4,5]
let setB: Set = [3,4,5,6,7]

let union: Set = setA.union(setB)
print(union)

let sortedUnion: [Int] = union.sorted()
print(sortedUnion)

let intersection: Set = setA.intersection(setB)
print(intersection)

let subtracting: Set = setA.subtracting(setB)
print(subtracting)
