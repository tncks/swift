let someInteger = 102

if someInteger < 100 {
  print("100 미만")
} else if someInteger > 100{
    print("100 초과")
  } else {
  print("100")
}