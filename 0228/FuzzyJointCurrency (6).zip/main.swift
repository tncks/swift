func sayHelloToFriends(me: String, friends: String...) -> String{
  return "Hello \(friends)! I'm \(me)!"
}

print(sayHelloToFriends(me: "yagom", friends: "hana", "eric"))
print(sayHelloToFriends(me: "yagom", friends: "hana"))
print(sayHelloToFriends(me: "god"))