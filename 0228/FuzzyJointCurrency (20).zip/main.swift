func printName(_ name: String) {
  print(name)
}

var myName : String? = "yagom"

printName(myName!)

myName = nil

//print(myName!)

var yourName: String! = nil

//printName(yourName)