let someInteger = 80

switch someInteger{
  case 0:
  print("zero")
  case 1..<100:
  print("1~99")
  case 100:
  print("100")
  case 101...Int.max:
  print("over 100")
  default:
  print("unknown")
}

