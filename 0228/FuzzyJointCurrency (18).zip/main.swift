func printName(_ name: String)
{
  print(name)
}

var myName: String! = nil

if let name: String = myName {
  printName(name)
} else {
  print("myName == nil")
}