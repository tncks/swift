var integers = [1,2,3,4,5]

repeat {
  integers.removeLast()
} while integers.count > 0

print(integers)