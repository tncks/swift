func sum(a: Int, b: Int) -> Int{
  return a + b
}

func printmyName(name: String) -> Void{
  print(name)
}

func printYourName(name: String){
  print(name)
}

func maximumInteger() -> Int{
  return Int.max
}

func hello() {
  print("hello~")
}

sum(a: 3, b: 5)
printmyName(name: "yagom")
printYourName(name: "hana")
maximumInteger()
hello()