var optionalValue: Int! = 100

switch optionalValue {
  case .none:
  print("This optionalValue is nil")
  case .some(let value):
  print("Value is \(value)")
}

optionalValue = optionalValue + 1
optionalValue = nil

//optionalValue = optionalValue + 1