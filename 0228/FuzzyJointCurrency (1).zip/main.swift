var anyDictionary: Dictionary = [String: Any]()

anyDictionary["somekey"] = "value"
anyDictionary["anotherKey"] = 100

print(anyDictionary)

anyDictionary["somekey"] = "dictionary"
print(anyDictionary)

anyDictionary.removeValue(forKey : "anotherKey")
anotherKey["somekey"] = nil
print(anyDictionary)