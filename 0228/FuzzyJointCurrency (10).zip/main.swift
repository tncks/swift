switch "yagom"
{
  case "jake":
  print("jake")
  case "yagom":
  print("this is yagom!")
  default:
  print("i dont know!!")
}