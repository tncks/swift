func someFunction(someOptionalParam: Int?) {
  
}

func someFunction(someParam: Int) {
  
}

someFunction(someOptionalParam: nil)
//someFunction(someParam: nil)