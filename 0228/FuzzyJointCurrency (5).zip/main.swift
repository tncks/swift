func greeting(to friend: String, from me: String = "yagom")
{
  print("Hello \(friend)! I'm \(me)")
}

greeting(to: "hana", from: "yagom")