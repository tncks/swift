var myName: String? = "yagom"
var yourName: String? = nil

if let name = myName, let friend = yourName {
  print("\(name) and \(friend)")
}

yourName = "hana"

if let name = myName, let friend = yourName {
  print("\(name) and \(friend)")
}