func greeting(to friend: String, from me: String) ->Void {
    print("Hello \(friend)! I'm \(me)")
}

var someFunction: (String, String) -> Void = greeting(to:from:)
someFunction("eric", "yagom")
someFunction = greeting(friend:me:)
someFunction("eric", "yaom")

func runAnother(function: (String, String) -> Void){
  function("jenny", "mike")
}

runAnother(function: greeting(friend:me:))

runAnother(function: someFunction)