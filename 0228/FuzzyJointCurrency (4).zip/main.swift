func greeting(friend: String, me: String = "yagom")
{
  print("Hello \(friend)! I'm \(me)")
}

greeting(friend: "hana")
greeting(friend: "john", me: "eric")