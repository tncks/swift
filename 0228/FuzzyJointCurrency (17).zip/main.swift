func printName(_ name: String)
{
  print(name)
}

var myName: String? = nil

//printName(myName)