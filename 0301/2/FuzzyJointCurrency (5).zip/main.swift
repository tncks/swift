struct Student {
  var name: String = ""
  var 'class': String = "Swift"
  var koreanAge: Int = 0
  
  var westernAge: Int {
    get {
      return koreanAge - 1
    }
    
    set(inputValue)
    {
      koreanAge = inputValue + 1
    }
  }
  
  static var typeDescription: String = "학생"
  
  var selfIntroduction: String {
    get {
      return "저는 \(self.class)반 \(name)입니다"
    }
  }
  
  static var selfIntroduction: String {
    return "학생타입입니다."
  }
}

print(Student.selfIntroduction)

var yagom: Student = Student()
yagom.koreanAge = 10

yagom.name = "yagomi"
print(yagom.name)

print(yagom.selfIntroduction)

print("제 한국 나이는 \(yagom.koreanAge)살이고, 미국나이는 \(yagom.westernAge)살입니다.")



























