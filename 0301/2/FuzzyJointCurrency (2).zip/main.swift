func calculate(a: Int, b: Int, method: (Int, Int) -> Int) -> Int {
  return method(a, b)
}

var result: Int

result = calculate(a: 10, b: 10, method: {
  return $0 + $1
})

print(result)