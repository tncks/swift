var a: Int = 100
var b: Int = 200

var sum: Int {
  return a + b
}

print(sum)