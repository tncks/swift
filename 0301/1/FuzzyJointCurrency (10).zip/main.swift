struct ValueType {
  var property = 1
}

class ReferenceType {
  var property = 1
}

let firstStructInstance = ValueType()

var secondStructInstance = ReferenceType()

secondStructInstance.property = 2

print(firstStructInstance.property)
print(secondStructInstance.property)

let firstClassRefence = ReferenceType()

let secondClassReference = firstClassRefence

secondClassReference.property = 2

print(firstClassRefence.property)
print(secondClassReference.property)