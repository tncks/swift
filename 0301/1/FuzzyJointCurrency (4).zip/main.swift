enum Weekday {
  case mon
  case tue
  case wed
  case thu, fri, sat, sun
}

var day: Weekday = Weekday.mon

day = .tue

print(day)

switch day {
  case .mon, .tue, .wed, .thu:
  print("평일입니다.")
  case Weekday.fri:
  print("불금 파티!!")
  case .sat, .sun:
  print("신나는 주말!!")
}