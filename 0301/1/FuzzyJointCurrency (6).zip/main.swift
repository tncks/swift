enum School: String{
  case elementary = "초등"
  case middle = "중등"
  case university
}

print(School.middle.rawValue)

print(School.university.rawValue)