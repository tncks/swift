class Student
{
  var name: String = "unknown"
  
  var 'class': String = "Swfit"
  
  class func selfIntroduce() {
    print("학생타입입니다.")
  }
  
  func selfIntroduce()
  {
    print("저는 \(self.class)반 \(name)입니다.")
  }
}

Student.selfIntroduce()

var yagom: Student = Student()

yagom.name = "yagomi"
yagom.class = "수위프트"
yagom.selfIntroduce()

let jina: Student = Student()
jina.name = "jina"
jina.selfIntroduce()