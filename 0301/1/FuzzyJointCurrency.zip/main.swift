struct Sample
{
  var mutableProperty: Int = 100
  let immutableProperty: Int = 200
  
  static var typeProperty: Int = 300
  
  func instanceMethod()
  {
    print("instance Method")
  }
  
  static func typeMethod()
  {
    print("type method")
  }
  
  
}


var mutable: Sample = Sample()

mutable.mutableProperty = 200

print(mutable.mutableProperty)

let immutable: Sample = Sample()

immutable.instanceMethod()

print(Sample.typeProperty)


Sample.typeProperty = 500
Sample.typeMethod()


print(Sample.typeProperty)

