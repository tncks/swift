struct Student
{
  var name: String = "unknown"
  
  var 'class': String = "Swift"
  
  static func selfIntroduce(){
    print("학생타입입니다.")
  }
  
  func selfIntroduce()
  {
    print("저는 \(self.class)반 \(name)입니다.")
  }
}

Student.selfIntroduce()

var yagom: Student = Student()
yagom.name = "yagom"
yagom.class = "스위프트"
yagom.selfIntroduce()

let jina: Student = Student()

jina.selfIntroduce()