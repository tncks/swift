enum Fruit: Int {
  case apple = 0
  case grape = 1
  case peach
}

let apple: Fruit? Fruit(rawValue: 0)

if let orange: Fruit = Fruit(rawValue: 5)
{
  print("rawValue 5에 해당하는 케이스는 \(orange)입니다.")
} else {
  print("rawValue 5에 해당하는 케이스가 없습니다.")
}


enum Month {
  case dec, jan, feb
  case mar, apr, may
  case jun, jul, aug
  case sep, oct, nov
  
  func printMessage() {
    switch self {
      case .mar, .apr, .may:
      print("따뜻한 봄")
      case .jun, .jul, .aug:
      print("여름 더워요~")
      case .sep, .oct, .nov:
      print("가을은 독서의 계절!")
      case .dec, .jan, .feb:
      print("추운 겨울입니다")
    }
  }
}