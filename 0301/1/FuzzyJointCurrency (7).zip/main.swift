enum Fruit: Int {
  case apple = 0
  case grape = 1
  case peach
}

let apple: Fruit? Fruit(rawValue: 0)

if let orange: Fruit = Fruit(rawValue: 5)
{
  print("rawValue 5에 해당하는 케이스는 \(orange)입니다.")
} else {
  print("rawValue 5에 해당하는 케이스가 없습니다.")
}