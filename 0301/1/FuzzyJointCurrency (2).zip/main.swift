class Sample
{
  var mutableProperty: Int = 100
  
  let immutableProperty: Int = 200
  
  static var typeProPerty: Int = 300
  
  func instanceMethod() {
    print("instance Method")
  }
  
  static func typeMethod() {
    print("type method - static")
  }
  
  class func classMethod() {
    print("type method - class")
  }
}

var mutableReference: Sample = Sample()
mutableReference.mutableProperty = 500

let immutableReference: Sample = Sample()

immutableReference.mutableProperty = 600

Sample.typeProPerty = 700
Sample.typeMethod()

