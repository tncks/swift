enum Fruit: Int {
  case apple = 0
  case grape = 1
  case peach
}
print("Fruit.peach.rawValue == \(Fruit.peach.rawValue)")

