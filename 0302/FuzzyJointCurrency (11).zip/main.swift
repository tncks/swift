var someInt: Int = 0

assert(someInt == 0, "someInt != 0")

func functionWithAssert(age: Int?) {
  assert(age != nil, "age == nil")
  
  assert((age! >= 0) && (age! <= 130), "나이값 입력이 잘못되었습니다.")
  print("당신의 나이는 \(age!)세 입니다.")
}

functionWithAssert(age: 50)




















