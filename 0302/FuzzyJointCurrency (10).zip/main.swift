class Person {
  var name: String = ""
  func breath() {
    print("숨을 쉽니다.")
  }
}

class Student: Person {
  var school: String = ""
  func goToSchool() {
    print("등교를 합니다.")
  }
}

class UniversityStudent: Student {
  var major: String = ""
  func goToMT() {
    print("멤버쉽 트레이닝을 갑니다!!")
  }
}

var mike: Person = UniversityStudent() as Person

var jenny: Person = Student()

var jina: Any = Person()

func doSomethingWithSwitch(someone: Person)
{
  switch someone {
    case is UniversityStudent:
    (someone as! UniversityStudent).goToMT()
    case is Student:
    (someone as! Student).goToSchool()
    case is Person:
    (someone as! Person).breath()
  }
}


doSomethingWithSwitch(someone: mike as Person)
doSomethingWithSwitch(someone: mike)
doSomethingWithSwitch(someone: jenny)
doSomethingWithSwitch(someone: yagom)

func doSomething(someone: Person)
{
  if let universityStudent = someone as? UniversityStudent {
    universityStudent.goToMT()
  } else if let student = someone as? Student {
    student.goToSchool()
  } else if let person = someone as? Person {
    person.breath()
  }
}

doSomething(someone: mike as Person)
doSomething(someone: mike)
doSomething(someone: jenny)
doSomething(someone: yagom)

























