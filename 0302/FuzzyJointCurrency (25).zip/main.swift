let someNumbers: [Int] = [2, 8, 15]

var result: Int = 0

for number in someNumbers {
  result += number
}

print(result)