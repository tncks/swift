let someNumbers: [Int] = [2, 8, 15]

let sum: Int = someNumbers.reduce(0, { (first: Int, second: Int) -> Int in 
print("\(first) + \(second)")
return first + second 
})

print(sum)

var subtract: Int = someNumbers.reduce(0, { (first: Int, second: Int) -> Int in
print("\(first) - \(second)")
return first - second
  })

print(subtract)

let sumFromThree = someNumbers.reduce(-3) {
  $0 + $1
}

print(sumFromThree)