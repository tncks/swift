let numbers: [Int] = [0, 1, 2, 3, 4]

var filtered: [Int] = [Int]()

for number in numbers {
  if number % 2 == 0 {
    filtered.append(number)
  }
}

print(filtered)