class Person {
  var name: String = ""
  func breath() {
    print("숨을 쉽니다.")
  }
}

class Student: Person {
  var school: String = ""
  func goToSchool() {
    print("등교를 합니다.")
  }
}

class UniversityStudent: Student {
  var major: String = ""
  func goToMT() {
    print("멤버쉽 트레이닝을 갑니다!!")
  }
}

var yagom: Person = Person()
var hana: Student = Student()
var jason: UniversityStudent = UniversityStudent()



































