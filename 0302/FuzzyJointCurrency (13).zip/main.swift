extension String {
  init(int: Int) {
    self = "\(int)"
  }
  
  int(double: Double) {
    self = "\(double)"
  }
}

let stringFromInt: String = String(int: 100)

let stringFromDouble: String = String(double: 200.0)

print(stringFromInt)
print(stringFromDouble)