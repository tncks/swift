class Person {
  var name: String = ""
  func breath() {
    print("숨을 쉽니다.")
  }
}

class Student: Person {
  var school: String = ""
  func goToSchool() {
    print("등교를 합니다.")
  }
}

class UniversityStudent: Student {
  var major: String = ""
  func goToMT() {
    print("멤버쉽 트레이닝을 갑니다!!")
  }
}

var yagom: Person = Person()
var hana: Student = Student()
var jason: UniversityStudent = UniversityStudent()

var result: Bool

result = yagom is Person
result = yagom is Student
result = yagom is UniversityStudent

result = hana is Person
result = hana is Student
result = hana is UniversityStudent

result = jason is Person
result = jason is Student
result = jason is UniversityStudent

if yagom is UniversityStudent {
  print("yagom은 대학생")
  
} else if yagom is Student {
  print("yagom은 학생")
} else if yagom is Person {
  print("yagom은 사람")
}

switch jason {
  case is Person:
  print("jason은 사람")
  case is Student:
  print("jason은 학생")
  case is UniversityStudent:
  print("jason은 대학생입니다.")
  default:
  print("jason은 사람도, 학생도, 대학생도 아닙니다.")
}

switch jason {
  case is UniversityStudent:
  print("jason은 대학생")
  case is Student:
  print("jason은 학생")
  case is Person:
  print("jason은 사람")
  default:
  print("jason은 아무것도 아닙니다.")
}






















