let numbers: [Int] = [0, 1, 2, 3, 4]
var doubleNumbers: [Int]
var strings: [String]

doubleNumbers = [Int]()
strings = [String]()

for number in numbers {
  doubleNumbers.append(number * 2)
  strings.append("\(number)")
}

print(doubleNumbers)
print(strings)